CHANGELOG

v1.0 initial build based on manual installation instructions. 
