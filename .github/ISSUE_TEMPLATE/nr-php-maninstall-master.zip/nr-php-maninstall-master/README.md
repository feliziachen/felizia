This script is publicly hosted on [New Relic's PHP docs](https://docs.newrelic.com/docs/agents/php-agent/advanced-installation/php-agent-installation-non-standard-php-advanced#manual-installation-script)



PHP-manual-install-script

===================

New Relic PHP Manual installation utility

Place nrmaninstall.php into your web servers Document Root. 

Once you have placed the file in your application's directory, visit the page in your browser. 

You should be able to execute the commands on that page to successfully install the PHP Agent. 


